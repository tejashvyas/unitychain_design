export default {
    facebook:{
        app_id: '2261924770802417'
    },
    instagram: {
        client_id: '1ff920eaf8874ebc8add3c4ae6e0a7d6',
        client_secret: '0777dc682dec45f4993c0849e08967b8',
        redirect_uri: 'https://dash.unitychain.io/app/my-social'
    },
    twitter: {
        loginUrl: 'http://localhost:3000/api/v1/auth/twitter',
        requestTokenUrl: 'http://localhost:3000/api/v1/auth/twitter/reverse',
        consumer_key: 'tHlUZ4sdENCu8vI0JpVloOXsJ',
        consumer_secret_key: 'ksw6wiI25dJDhzNY5eTaEYVmbcIjg6zJ7Wu0geZQNsWzgZr2ik'
    }
}