import AppsPage from './apps';

export { AppsPage };
