import PersonalFilesPage from './personalFilesPage';


export { PersonalFilesPage }