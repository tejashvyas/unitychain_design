import ProfilePage from './profilePage';


export { ProfilePage }