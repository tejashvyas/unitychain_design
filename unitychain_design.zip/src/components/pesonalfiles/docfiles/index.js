import PdfComponent from './pdfComponent';
import DocComponent from './docComponent';
import PptComponent from './pptComponent';
import XlsComponent from './xlsComponent';
import ZipComponent from './zipComponent';


export { PdfComponent, DocComponent, PptComponent, XlsComponent, ZipComponent };
