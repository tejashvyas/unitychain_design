import MyUploadsComponent from './myUploadsComponent';
import MediaComponent from './mediaComponent';
import DocumentsComponent from './documentsComponent';

export { MyUploadsComponent, MediaComponent, DocumentsComponent };
