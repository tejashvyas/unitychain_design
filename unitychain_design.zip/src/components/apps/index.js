import MySocialComponent from './mySocialComponent';

export { MySocialComponent };
