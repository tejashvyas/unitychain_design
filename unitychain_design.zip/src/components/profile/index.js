import ProfileComponent from './profileComponent';
import ProfileUploadComponent from './profileUploadComponent';
import AccountSettingComponent from './accountSettingComponent';
import MyPreferenceComponent from './myPreferenceComponent';

export { ProfileComponent, ProfileUploadComponent, AccountSettingComponent, MyPreferenceComponent };
